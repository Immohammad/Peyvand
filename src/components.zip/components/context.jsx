import {createContext} from 'react';

const User=createContext({
    USER:""
});

export default User;