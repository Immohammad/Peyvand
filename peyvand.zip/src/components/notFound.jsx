import React from 'react'

function NotFound() {
  return (
    <div>صفحه مورد نظر شما یافت نشد.</div>
  )
}

export default NotFound